DIGITAL LITERACY TRAINING
Partner marketing kit from Mercer Med Tech
Prepared for the WorkFirst New Jersey team at Hunterdon County Educational
Services Commission.

====================================================================
WHICH FOLDER
====================================================================
"Co-branded (with Hunterdon ESC)"  Mercer Med Tech plus the Hunterdon County
                                   Educational Services Commission mark, an
                                   "in partnership with" line, and the line
                                   "Shared by Hunterdon County Educational
                                   Services Commission, WorkFirst New Jersey".
"Mercer Med Tech only"             The same pieces without the partner mark.

Pick one folder and use it throughout, so everything you post looks like one
set. Both folders contain the same file names.

====================================================================
WHICH FILE
====================================================================
instagram-post-EN.png          1080 x 1350. The 4:5 feed post. Best size for
instagram-post-ES.png          Instagram and Facebook feeds.

instagram-post-square-EN.png   1080 x 1080. The square version of the same
instagram-post-square-ES.png   post, for grids and profiles that need a square.

instagram-story-EN.png         1080 x 1920. Story or reel cover. Everything
instagram-story-ES.png         sits inside the middle of the frame, so phone
                               chrome and a link sticker will not cover it.
                               Carries a QR code to the sign-up page.

facebook-post-EN.png           1200 x 630. Use as the image on a Facebook post
facebook-post-ES.png           or as a link preview image.

flyer-EN.pdf / flyer-ES.pdf    US Letter, one page, print ready.
flyer-EN.png / flyer-ES.png    The same flyer as a 300 dpi picture (2550 x
                               3300), for screens, texts and attachments.

social-captions.txt            Captions to paste, English and Spanish, long and
                               short, with hashtags.
email-template.txt             Plain text email to forward.
email-template.html            The same email, styled. Open it in a browser to
                               preview, or paste the source into your email
                               tool as HTML.

EN is English. ES is Spanish. Post both, or pick the one your audience reads.

====================================================================
WORDING RULES (please keep these if you write your own copy)
====================================================================
1. Every piece must carry this sentence word for word:
   "The funding for this initiative is being provided by the New Jersey
   Department of Labor and Workforce Development."
2. Eligibility is always written as "TANF or SNAP". Do not swap in another
   assistance program name and do not describe the audience by income.
3. Do not say that someone must be referred by a caseworker in order to join.
4. Do not name any other Mercer Med Tech program in Digital Literacy material.
   This material is funded for Digital Literacy Training only.
5. Delivery is written exactly like this: "Classes are online. In-person
   support is available at our Lawrenceville campus during scheduled office
   hours." No days, no times, no standing weekly session.
6. Do not promise a free laptop. Say that a laptop and internet access can be
   provided when needed.
7. Do not print a phone number. Send people to the sign-up page. The email
   address is the secondary contact.
8. The Spanish name of the program is "Capacitacion en Habilidades Digitales
   (Digital Literacy Training)". Keep the English name in parentheses the
   first time it appears.
9. Plain words, a respectful tone, no exclamation marks, and nothing that
   suggests the reader is starting from nothing.

====================================================================
THE FACTS, IN ONE PLACE
====================================================================
Cost           No cost if you qualify. For people receiving TANF or SNAP.
Length         About 5 to 6 weeks, in small groups.
Language       English and Spanish.
Counties       Hunterdon, Middlesex, Monmouth, Mercer, Ocean, Somerset, Union.
You learn      Computer basics, email and internet, Microsoft Office and
               Google Workspace, online safety, AI at work, money management,
               resume and interviews.
You leave with An industry-recognized credential, including an AI Literacy
               Microcredential from NJIT, a finished resume, and help finding
               work with check-ins at 30, 60 and 90 days.
Delivery       Classes are online. In-person support is available at our
               Lawrenceville campus during scheduled office hours.
Support        A laptop and internet access can be provided when needed.
Start          The first group starts early October 2026. New groups start
               every 5 to 6 weeks.
Sign up        mercermedtech.com/digital-literacy/sign-up
Spanish        mercermedtech.com/es/digital-literacy/sign-up
Email          mercermedtech@gmail.com
Campus         168 Franklin Corner Rd, Bldg 2, Suite 140, Lawrenceville, NJ
               08648

====================================================================
NOTES
====================================================================
The Hunterdon County Educational Services Commission mark used in the
co-branded pieces was taken from hunterdonesc.org. If your team has a higher
resolution file or a preferred lockup, send it over and we will swap it in.

The pieces do not carry a New Jersey Department of Labor and Workforce
Development logo. The department's website publishes its name as type rather
than as a logo file, so the funding sentence appears on its own, which is what
the department asked for. If NJDOL supplies a logo file we will add it to the
flyer footer.

The QR codes on the story and the flyer point to the sign-up page. That page
goes live with the first group.

Questions or edits: mercermedtech@gmail.com
